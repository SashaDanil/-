"""
Информационная система учёта техники в техникуме
Flask-приложение для учебной практики ПМ 06
"""

from flask import Flask, render_template, request, redirect, url_for, flash, session, send_file
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date
import os
import shutil
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = 'uchebnaya-praktika-pm06-secret-key-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///equipment.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# ==================== МОДЕЛИ ====================

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    full_name = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), default='operator')  # admin / operator

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Equipment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    inventory_number = db.Column(db.String(50), unique=True, nullable=False)
    name = db.Column(db.String(150), nullable=False)
    equipment_type = db.Column(db.String(80), nullable=False)  # ПК, Ноутбук, Проектор, Принтер и т.д.
    model = db.Column(db.String(100))
    serial_number = db.Column(db.String(100))
    location = db.Column(db.String(100), nullable=False)  # Кабинет / аудитория
    status = db.Column(db.String(30), default='В эксплуатации')  # В эксплуатации, В ремонте, Списано, На складе
    responsible_person = db.Column(db.String(120))
    purchase_date = db.Column(db.Date)
    warranty_until = db.Column(db.Date)
    cost = db.Column(db.Float, default=0.0)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<Equipment {self.inventory_number}: {self.name}>'


class MaintenanceLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'), nullable=False)
    action = db.Column(db.String(100), nullable=False)  # Ремонт, Профилактика, Перемещение и т.д.
    description = db.Column(db.Text)
    performed_by = db.Column(db.String(120))
    performed_at = db.Column(db.DateTime, default=datetime.utcnow)
    equipment = db.relationship('Equipment', backref=db.backref('logs', lazy=True))


# ==================== ДЕКОРАТОРЫ ====================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Требуется авторизация', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Требуется авторизация', 'warning')
            return redirect(url_for('login'))
        user = User.query.get(session['user_id'])
        if not user or user.role != 'admin':
            flash('Доступ только для администратора', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function


# ==================== МАРШРУТЫ ====================

@app.route('/')
@login_required
def index():
    total = Equipment.query.count()
    in_use = Equipment.query.filter_by(status='В эксплуатации').count()
    in_repair = Equipment.query.filter_by(status='В ремонте').count()
    written_off = Equipment.query.filter_by(status='Списано').count()
    on_stock = Equipment.query.filter_by(status='На складе').count()
    
    recent = Equipment.query.order_by(Equipment.updated_at.desc()).limit(5).all()
    
    return render_template('index.html',
                           total=total, in_use=in_use, in_repair=in_repair,
                           written_off=written_off, on_stock=on_stock, recent=recent)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['full_name'] = user.full_name
            session['role'] = user.role
            flash(f'Добро пожаловать, {user.full_name}!', 'success')
            return redirect(url_for('index'))
        flash('Неверный логин или пароль', 'danger')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('login'))


@app.route('/equipment')
@login_required
def equipment_list():
    status_filter = request.args.get('status', '')
    type_filter = request.args.get('type', '')
    search = request.args.get('search', '')
    
    query = Equipment.query
    
    if status_filter:
        query = query.filter_by(status=status_filter)
    if type_filter:
        query = query.filter_by(equipment_type=type_filter)
    if search:
        query = query.filter(
            db.or_(
                Equipment.name.ilike(f'%{search}%'),
                Equipment.inventory_number.ilike(f'%{search}%'),
                Equipment.location.ilike(f'%{search}%'),
                Equipment.responsible_person.ilike(f'%{search}%')
            )
        )
    
    items = query.order_by(Equipment.inventory_number).all()
    types = db.session.query(Equipment.equipment_type).distinct().all()
    types = [t[0] for t in types]
    
    return render_template('equipment_list.html', items=items, types=types,
                           status_filter=status_filter, type_filter=type_filter, search=search)


@app.route('/equipment/add', methods=['GET', 'POST'])
@login_required
def equipment_add():
    if request.method == 'POST':
        inv = request.form.get('inventory_number', '').strip()
        if Equipment.query.filter_by(inventory_number=inv).first():
            flash('Инвентарный номер уже существует', 'danger')
            return redirect(url_for('equipment_add'))
        
        eq = Equipment(
            inventory_number=inv,
            name=request.form.get('name'),
            equipment_type=request.form.get('equipment_type'),
            model=request.form.get('model'),
            serial_number=request.form.get('serial_number'),
            location=request.form.get('location'),
            status=request.form.get('status', 'В эксплуатации'),
            responsible_person=request.form.get('responsible_person'),
            cost=float(request.form.get('cost') or 0),
            notes=request.form.get('notes')
        )
        
        pd = request.form.get('purchase_date')
        if pd:
            eq.purchase_date = datetime.strptime(pd, '%Y-%m-%d').date()
        wu = request.form.get('warranty_until')
        if wu:
            eq.warranty_until = datetime.strptime(wu, '%Y-%m-%d').date()
        
        db.session.add(eq)
        db.session.commit()
        
        log = MaintenanceLog(equipment_id=eq.id, action='Добавление',
                             description='Оборудование добавлено в систему',
                             performed_by=session.get('full_name'))
        db.session.add(log)
        db.session.commit()
        
        flash('Оборудование успешно добавлено', 'success')
        return redirect(url_for('equipment_list'))
    
    return render_template('equipment_form.html', equipment=None)


@app.route('/equipment/<int:eq_id>')
@login_required
def equipment_view(eq_id):
    eq = Equipment.query.get_or_404(eq_id)
    logs = MaintenanceLog.query.filter_by(equipment_id=eq_id).order_by(MaintenanceLog.performed_at.desc()).all()
    return render_template('equipment_view.html', equipment=eq, logs=logs)


@app.route('/equipment/<int:eq_id>/edit', methods=['GET', 'POST'])
@login_required
def equipment_edit(eq_id):
    eq = Equipment.query.get_or_404(eq_id)
    if request.method == 'POST':
        inv = request.form.get('inventory_number', '').strip()
        existing = Equipment.query.filter_by(inventory_number=inv).first()
        if existing and existing.id != eq.id:
            flash('Инвентарный номер уже существует', 'danger')
            return redirect(url_for('equipment_edit', eq_id=eq_id))
        
        old_status = eq.status
        eq.inventory_number = inv
        eq.name = request.form.get('name')
        eq.equipment_type = request.form.get('equipment_type')
        eq.model = request.form.get('model')
        eq.serial_number = request.form.get('serial_number')
        eq.location = request.form.get('location')
        eq.status = request.form.get('status')
        eq.responsible_person = request.form.get('responsible_person')
        eq.cost = float(request.form.get('cost') or 0)
        eq.notes = request.form.get('notes')
        
        pd = request.form.get('purchase_date')
        eq.purchase_date = datetime.strptime(pd, '%Y-%m-%d').date() if pd else None
        wu = request.form.get('warranty_until')
        eq.warranty_until = datetime.strptime(wu, '%Y-%m-%d').date() if wu else None
        
        db.session.commit()
        
        if old_status != eq.status:
            log = MaintenanceLog(equipment_id=eq.id, action='Изменение статуса',
                                 description=f'Статус изменён: {old_status} → {eq.status}',
                                 performed_by=session.get('full_name'))
            db.session.add(log)
            db.session.commit()
        
        flash('Данные обновлены', 'success')
        return redirect(url_for('equipment_view', eq_id=eq.id))
    
    return render_template('equipment_form.html', equipment=eq)


@app.route('/equipment/<int:eq_id>/delete', methods=['POST'])
@admin_required
def equipment_delete(eq_id):
    eq = Equipment.query.get_or_404(eq_id)
    MaintenanceLog.query.filter_by(equipment_id=eq_id).delete()
    db.session.delete(eq)
    db.session.commit()
    flash('Оборудование удалено', 'success')
    return redirect(url_for('equipment_list'))


@app.route('/equipment/<int:eq_id>/log', methods=['POST'])
@login_required
def equipment_add_log(eq_id):
    eq = Equipment.query.get_or_404(eq_id)
    action = request.form.get('action')
    description = request.form.get('description')
    
    log = MaintenanceLog(equipment_id=eq.id, action=action,
                         description=description,
                         performed_by=session.get('full_name'))
    db.session.add(log)
    
    if action == 'Ремонт':
        eq.status = 'В ремонте'
    elif action == 'Возврат из ремонта':
        eq.status = 'В эксплуатации'
    elif action == 'Списание':
        eq.status = 'Списано'
    
    db.session.commit()
    flash('Запись обслуживания добавлена', 'success')
    return redirect(url_for('equipment_view', eq_id=eq.id))


@app.route('/reports')
@login_required
def reports():
    by_type = db.session.query(
        Equipment.equipment_type, db.func.count(Equipment.id)
    ).group_by(Equipment.equipment_type).all()
    
    by_status = db.session.query(
        Equipment.status, db.func.count(Equipment.id)
    ).group_by(Equipment.status).all()
    
    by_location = db.session.query(
        Equipment.location, db.func.count(Equipment.id)
    ).group_by(Equipment.location).order_by(db.func.count(Equipment.id).desc()).all()
    
    total_cost = db.session.query(db.func.sum(Equipment.cost)).scalar() or 0
    
    return render_template('reports.html', by_type=by_type, by_status=by_status,
                           by_location=by_location, total_cost=total_cost)


@app.route('/backup')
@admin_required
def create_backup():
    """Создание резервной копии БД"""
    backup_dir = os.path.join(app.root_path, 'backups')
    os.makedirs(backup_dir, exist_ok=True)
    
    src = os.path.join(app.instance_path, 'equipment.db')
    if not os.path.exists(src):
        # Альтернативный путь
        src = os.path.join(app.root_path, 'instance', 'equipment.db')
    
    if not os.path.exists(src):
        flash('База данных не найдена', 'danger')
        return redirect(url_for('index'))
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    dst = os.path.join(backup_dir, f'equipment_backup_{timestamp}.db')
    shutil.copy2(src, dst)
    
    flash(f'Резервная копия создана: equipment_backup_{timestamp}.db', 'success')
    return redirect(url_for('index'))


@app.route('/users')
@admin_required
def users_list():
    users = User.query.all()
    return render_template('users.html', users=users)


# ==================== ИНИЦИАЛИЗАЦИЯ ====================

def init_db():
    with app.app_context():
        db.create_all()
        
        # Создаём пользователей по умолчанию
        if not User.query.filter_by(username='admin').first():
            admin = User(username='admin', full_name='Администратор системы', role='admin')
            admin.set_password('admin123')
            db.session.add(admin)
        
        if not User.query.filter_by(username='operator').first():
            op = User(username='operator', full_name='Оператор учёта', role='operator')
            op.set_password('operator123')
            db.session.add(op)
        
        # Демо-данные
        if Equipment.query.count() == 0:
            demo = [
                Equipment(inventory_number='ТК-001', name='Системный блок', equipment_type='ПК',
                          model='Intel Core i5-10400', location='Каб. 101', status='В эксплуатации',
                          responsible_person='Иванов И.И.', cost=45000,
                          purchase_date=date(2022, 9, 1)),
                Equipment(inventory_number='ТК-002', name='Монитор 24"', equipment_type='Монитор',
                          model='Samsung S24R350', location='Каб. 101', status='В эксплуатации',
                          responsible_person='Иванов И.И.', cost=12000,
                          purchase_date=date(2022, 9, 1)),
                Equipment(inventory_number='ТК-003', name='Ноутбук', equipment_type='Ноутбук',
                          model='Lenovo IdeaPad 3', location='Каб. 205', status='В эксплуатации',
                          responsible_person='Петрова А.С.', cost=55000,
                          purchase_date=date(2023, 3, 15)),
                Equipment(inventory_number='ТК-004', name='Проектор', equipment_type='Проектор',
                          model='Epson EB-X06', location='Каб. 301', status='В ремонте',
                          responsible_person='Сидоров В.П.', cost=38000,
                          purchase_date=date(2021, 11, 20)),
                Equipment(inventory_number='ТК-005', name='МФУ', equipment_type='Принтер',
                          model='HP LaserJet Pro MFP M28', location='Каб. 110', status='В эксплуатации',
                          responsible_person='Козлова Е.Н.', cost=15000,
                          purchase_date=date(2023, 1, 10)),
                Equipment(inventory_number='ТК-006', name='Интерактивная доска', equipment_type='Доска',
                          model='Smart Board SBX880', location='Каб. 205', status='В эксплуатации',
                          responsible_person='Петрова А.С.', cost=120000,
                          purchase_date=date(2020, 8, 25)),
                Equipment(inventory_number='ТК-007', name='Коммутатор 24 порта', equipment_type='Сетевое оборудование',
                          model='Cisco SG350-28', location='Серверная', status='В эксплуатации',
                          responsible_person='Администратор сети', cost=45000,
                          purchase_date=date(2022, 5, 12)),
                Equipment(inventory_number='ТК-008', name='Системный блок (старый)', equipment_type='ПК',
                          model='Intel Core i3-7100', location='Склад', status='Списано',
                          responsible_person='—', cost=25000,
                          purchase_date=date(2018, 9, 1)),
            ]
            for e in demo:
                db.session.add(e)
        
        db.session.commit()


if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)
